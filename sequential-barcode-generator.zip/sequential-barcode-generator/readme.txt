=== Sequential Barcode Generator===
Contributors: PMG Dimitrovgrad
Stable tag: 0.1
Tested up to: 5.8
Requires at least: 4.6

== Description ==

This is a barcode generator, which was made as part of a school project.